#include "syscall.h"
#include "copyright.h" 
#define MAX_BUFFER_LENGTH 255

int main(){

    Print("buffer\n");

    Halt();
    return 0;
}
